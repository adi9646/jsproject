document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');
  const emailInput = document.getElementById('email');
  const contactInput = document.getElementById('contact');

  form.addEventListener('submit', function(event) {
    const email = emailInput.value.trim();
    const contact = contactInput.value.trim();

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const contactPattern = /^\d{10}$/;

    if (!emailPattern.test(email)) {
      alert('Please enter a valid email address.');
      emailInput.focus();
      event.preventDefault();
      return;
    }

    if (!contactPattern.test(contact)) {
      alert('Contact number must be exactly 10 digits.');
      contactInput.focus();
      event.preventDefault();
      return;
    }

    alert('Sign up form submitted successfully!');
  });
});
